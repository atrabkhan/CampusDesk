namespace CampusDesk.Models;
public class TicketIndexViewModel
{
    public List<Ticket> Tickets { get; set; } = new();
    public int Total { get; set; }
    public int Open { get; set; }
    public int Pending { get; set; }
    public int Resolved { get; set; }
    public TicketStatus? StatusFilter { get; set; }
    public TicketCategory? CategoryFilter { get; set; }
}
