using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Identity;
namespace CampusDesk.Models;

public class Ticket
{
    public int Id { get; set; }

    [Required, StringLength(100, MinimumLength = 5)]
    public string Title { get; set; } = string.Empty;

    [Required, StringLength(2000, MinimumLength = 10)]
    public string Description { get; set; } = string.Empty;

    [Required] public TicketCategory Category { get; set; }
    [Required] public TicketPriority Priority { get; set; } = TicketPriority.Medium;
    public TicketStatus Status { get; set; } = TicketStatus.Open;

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? ResolvedAt { get; set; }

    public string StudentId { get; set; } = string.Empty;
    public IdentityUser? Student { get; set; }

    public string? AssignedAdminId { get; set; }
    public IdentityUser? AssignedAdmin { get; set; }

    public bool IsDeleted { get; set; }   // soft delete
    public List<TicketComment> Comments { get; set; } = new();
}
