namespace CampusDesk.Models;
public enum TicketCategory { IT, Hostel, Academic, Infrastructure }
public enum TicketPriority { Low, Medium, High, Urgent }
public enum TicketStatus { Open, InProgress, Resolved, Closed }
