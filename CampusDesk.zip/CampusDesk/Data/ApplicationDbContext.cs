using CampusDesk.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
namespace CampusDesk.Data;

public class ApplicationDbContext : IdentityDbContext<IdentityUser>
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

    public DbSet<Ticket> Tickets => Set<Ticket>();
    public DbSet<TicketComment> TicketComments => Set<TicketComment>();

    protected override void OnModelCreating(ModelBuilder b)
    {
        base.OnModelCreating(b);

        b.Entity<Ticket>(e =>
        {
            e.Property(t => t.Title).HasMaxLength(100).IsRequired();
            e.Property(t => t.Category).HasConversion<string>().HasMaxLength(20);
            e.Property(t => t.Priority).HasConversion<string>().HasMaxLength(20);
            e.Property(t => t.Status).HasConversion<string>().HasMaxLength(20);

            e.HasOne(t => t.Student).WithMany()
             .HasForeignKey(t => t.StudentId).OnDelete(DeleteBehavior.Restrict);
            e.HasOne(t => t.AssignedAdmin).WithMany()
             .HasForeignKey(t => t.AssignedAdminId).OnDelete(DeleteBehavior.SetNull);
            e.HasMany(t => t.Comments).WithOne(c => c.Ticket)
             .HasForeignKey(c => c.TicketId).OnDelete(DeleteBehavior.Cascade);

            e.HasQueryFilter(t => !t.IsDeleted);   // soft delete filter
        });

        b.Entity<TicketComment>().HasQueryFilter(c => !c.Ticket!.IsDeleted);
    }
}
