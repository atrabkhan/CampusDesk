# CampusDesk - College Helpdesk Ticketing System
Author: Md Atrab | Enrolment No: 2405101270244 | BCA Hons, Div C | Subject: ASP.NET

## Run
```
dotnet restore
dotnet tool install --global dotnet-ef        # once
dotnet ef migrations add InitialCreate
dotnet ef database update
dotnet run
```
Default admin: admin@campusdesk.com / Admin@123
Registering a new account automatically gives the Student role.
