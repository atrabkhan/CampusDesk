using CampusDesk.Data;
using CampusDesk.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
namespace CampusDesk.Controllers;

[Authorize]
public class TicketsController : Controller
{
    private readonly ApplicationDbContext _db;
    private readonly UserManager<IdentityUser> _users;

    public TicketsController(ApplicationDbContext db, UserManager<IdentityUser> users)
    { _db = db; _users = users; }

    public async Task<IActionResult> Index(TicketStatus? status, TicketCategory? category)
    {
        var uid = _users.GetUserId(User)!;
        var isAdmin = User.IsInRole("Admin");

        var baseQ = _db.Tickets.AsNoTracking().Include(t => t.Student).AsQueryable();
        if (!isAdmin) baseQ = baseQ.Where(t => t.StudentId == uid);

        var vm = new TicketIndexViewModel
        {
            Total = await baseQ.CountAsync(),
            Open = await baseQ.CountAsync(t => t.Status == TicketStatus.Open),
            Pending = await baseQ.CountAsync(t => t.Status == TicketStatus.InProgress),
            Resolved = await baseQ.CountAsync(t => t.Status == TicketStatus.Resolved || t.Status == TicketStatus.Closed),
            StatusFilter = status,
            CategoryFilter = category
        };

        var q = baseQ;
        if (isAdmin && status.HasValue) q = q.Where(t => t.Status == status);
        if (isAdmin && category.HasValue) q = q.Where(t => t.Category == category);
        vm.Tickets = await q.OrderByDescending(t => t.CreatedAt).ToListAsync();
        return View(vm);
    }

    [Authorize(Roles = "Student")]
    public IActionResult Create() => View(new Ticket());

    [HttpPost, ValidateAntiForgeryToken, Authorize(Roles = "Student")]
    public async Task<IActionResult> Create([Bind("Title,Description,Category,Priority")] Ticket ticket)
    {
        if (!ModelState.IsValid) return View(ticket);
        ticket.StudentId = _users.GetUserId(User)!;
        ticket.Status = TicketStatus.Open;
        ticket.CreatedAt = DateTime.UtcNow;
        _db.Add(ticket);
        await _db.SaveChangesAsync();
        TempData["Success"] = "Your ticket has been submitted.";
        return RedirectToAction(nameof(Details), new { id = ticket.Id });
    }

    public async Task<IActionResult> Details(int id)
    {
        var ticket = await _db.Tickets
            .Include(t => t.Student).Include(t => t.AssignedAdmin)
            .Include(t => t.Comments.OrderBy(c => c.Timestamp))
            .FirstOrDefaultAsync(t => t.Id == id);
        if (ticket == null) return NotFound();
        if (!User.IsInRole("Admin") && ticket.StudentId != _users.GetUserId(User)) return Forbid();

        if (User.IsInRole("Admin"))
        {
            var admins = await _users.GetUsersInRoleAsync("Admin");
            ViewBag.Admins = new SelectList(admins, "Id", "UserName", ticket.AssignedAdminId);
        }
        return View(ticket);
    }

    // Append-only comments: no edit or delete actions exist.
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> AddComment(int ticketId, string commentText)
    {
        var ticket = await _db.Tickets.FirstOrDefaultAsync(t => t.Id == ticketId);
        if (ticket == null) return NotFound();
        if (!User.IsInRole("Admin") && ticket.StudentId != _users.GetUserId(User)) return Forbid();

        if (string.IsNullOrWhiteSpace(commentText) || commentText.Length > 1000)
        {
            TempData["Error"] = "Comment must be between 1 and 1000 characters.";
            return RedirectToAction(nameof(Details), new { id = ticketId });
        }
        _db.TicketComments.Add(new TicketComment
        {
            TicketId = ticketId,
            UserId = _users.GetUserId(User)!,
            UserName = User.Identity!.Name!,
            CommentText = commentText.Trim()
        });
        await _db.SaveChangesAsync();
        TempData["Success"] = "Comment added.";
        return RedirectToAction(nameof(Details), new { id = ticketId });
    }

    [HttpPost, ValidateAntiForgeryToken, Authorize(Roles = "Admin")]
    public async Task<IActionResult> UpdateStatus(int id, TicketStatus status, string? assignedAdminId)
    {
        var ticket = await _db.Tickets.FirstOrDefaultAsync(t => t.Id == id);
        if (ticket == null) return NotFound();

        ticket.Status = status;
        ticket.AssignedAdminId = string.IsNullOrEmpty(assignedAdminId) ? null : assignedAdminId;
        ticket.ResolvedAt = (status == TicketStatus.Resolved || status == TicketStatus.Closed)
            ? (ticket.ResolvedAt ?? DateTime.UtcNow) : null;
        await _db.SaveChangesAsync();
        TempData["Success"] = "Ticket updated.";
        return RedirectToAction(nameof(Details), new { id });
    }

    [HttpPost, ValidateAntiForgeryToken, Authorize(Roles = "Admin")]
    public async Task<IActionResult> Delete(int id)
    {
        var ticket = await _db.Tickets.FirstOrDefaultAsync(t => t.Id == id);
        if (ticket != null) { ticket.IsDeleted = true; await _db.SaveChangesAsync(); }
        TempData["Success"] = "Ticket removed.";
        return RedirectToAction(nameof(Index));
    }
}
