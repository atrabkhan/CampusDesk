using Microsoft.AspNetCore.Mvc;
namespace CampusDesk.Controllers;
public class HomeController : Controller
{
    public IActionResult Index() => View();
    public IActionResult Error() => View();
}
