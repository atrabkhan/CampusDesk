// CampusDesk - Author: Md Atrab | Enrolment No: 2405101270244 | BCA Hons, Div C | ASP.NET
using CampusDesk.Data;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddDbContext<ApplicationDbContext>(o =>
    o.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

builder.Services.AddDefaultIdentity<IdentityUser>(o =>
{
    o.SignIn.RequireConfirmedAccount = false;
    o.Password.RequiredLength = 6;
    o.Password.RequireNonAlphanumeric = false;
})
.AddRoles<IdentityRole>()
.AddEntityFrameworkStores<ApplicationDbContext>();

builder.Services.ConfigureApplicationCookie(o =>
{
    o.LoginPath = "/Identity/Account/Login";
    o.AccessDeniedPath = "/Identity/Account/AccessDenied";
    o.ExpireTimeSpan = TimeSpan.FromHours(2);
    o.SlidingExpiration = true;
    o.Cookie.HttpOnly = true;
});

builder.Services.AddControllersWithViews();
builder.Services.AddRazorPages();

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseAuthentication();
app.UseAuthorization();

// Newly registered users get the Student role automatically (cookie refreshed so the role applies at once)
app.Use(async (ctx, next) =>
{
    if (ctx.User.Identity?.IsAuthenticated == true && !ctx.User.IsInRole("Admin") && !ctx.User.IsInRole("Student"))
    {
        var um = ctx.RequestServices.GetRequiredService<UserManager<IdentityUser>>();
        var sm = ctx.RequestServices.GetRequiredService<SignInManager<IdentityUser>>();
        var user = await um.GetUserAsync(ctx.User);
        if (user != null)
        {
            await um.AddToRoleAsync(user, "Student");
            await sm.RefreshSignInAsync(user);
            ctx.Response.Redirect(ctx.Request.Path + ctx.Request.QueryString);
            return;
        }
    }
    await next();
});

app.MapControllerRoute(name: "default", pattern: "{controller=Home}/{action=Index}/{id?}");
app.MapRazorPages();

// Seed roles and a default admin
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();
    await db.Database.MigrateAsync();
    var roles = scope.ServiceProvider.GetRequiredService<RoleManager<IdentityRole>>();
    var users = scope.ServiceProvider.GetRequiredService<UserManager<IdentityUser>>();
    foreach (var r in new[] { "Student", "Admin" })
        if (!await roles.RoleExistsAsync(r)) await roles.CreateAsync(new IdentityRole(r));

    const string adminEmail = "admin@campusdesk.com";
    if (await users.FindByEmailAsync(adminEmail) == null)
    {
        var admin = new IdentityUser { UserName = adminEmail, Email = adminEmail, EmailConfirmed = true };
        if ((await users.CreateAsync(admin, "Admin@123")).Succeeded)
            await users.AddToRoleAsync(admin, "Admin");
    }
}

app.Run();
